package com.okex.open.api.websocket;


public abstract class WebSocketAdapter implements WebSocketListener {

}
