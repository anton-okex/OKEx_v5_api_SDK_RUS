﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OKExSDKLibrary
{
    class GeneralApi
    {
    }
}
