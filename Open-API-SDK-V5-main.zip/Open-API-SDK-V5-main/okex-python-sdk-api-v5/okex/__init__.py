"""An unofficial Python wrapper for the OKEx exchange API v3

.. moduleauthor:: Sam McHardy

"""
